export default [
  require('D:\\Develop\\cbsjz-docusaurus\\node_modules\\infima\\dist\\css\\default\\default.css'),
  require('D:\\Develop\\cbsjz-docusaurus\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages'),
  require('D:\\Develop\\cbsjz-docusaurus\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress'),
  require('D:\\Develop\\cbsjz-docusaurus\\src\\css\\custom.css'),
];
